
import java.util.LinkedList;

public class DateSummary implements Comparable {

  String date;
  float soilTempAAve;
  float soilTempAMax;
  float soilTempAMin;
  float soilTempBAve;
  float soilTempBMax;
  float soilTempBMin;
  float humidAve;
  float humidMax;
  float humidMin;
  float airTempAve;
  float airTempMax;
  float airTempMin;
  float dewPointAve;
  float dewPointMax;
  float dewPointMin;

  public DateSummary(String date, LinkedList<Float> soilTempA, LinkedList<Float> soilTempB,
          LinkedList<Float> humidity, LinkedList<Float> airTemp, LinkedList<Float> dewPoint) {

    this.date = date;

    this.soilTempAAve = average(soilTempA);
    this.soilTempAMax = max(soilTempA);
    this.soilTempAMin = min(soilTempA);

    this.soilTempBAve = average(soilTempB);
    this.soilTempBMax = max(soilTempB);
    this.soilTempBMin = min(soilTempB);

    this.humidAve = average(humidity);
    this.humidMax = max(humidity);
    this.humidMin = min(humidity);

    this.airTempAve = average(airTemp);
    this.airTempMax = max(airTemp);
    this.airTempMin = min(airTemp);

    this.dewPointAve = average(dewPoint);
    this.dewPointMax = max(dewPoint);
    this.dewPointMin = min(dewPoint);

  }

  public float average(LinkedList<Float> values) {
    double runningTally = 0.0;
    for (float value : values) {
      runningTally += value;
    }
    return (float) (runningTally / values.size());
  }

  public float max(LinkedList<Float> values) {
    float highestSeen = Float.NEGATIVE_INFINITY;
    for (float value : values) {
      if (value > highestSeen) {
        highestSeen = value;
      }
    }
    return highestSeen;
  }

  public float min(LinkedList<Float> values) {
    float lowestSeen = Float.POSITIVE_INFINITY;
    for (float value : values) {
      if (value < lowestSeen) {
        lowestSeen = value;
      }
    }
    return lowestSeen;
  }

  public float getAirTempAve() {
    return airTempAve;
  }

  public void setAirTempAve(float airTempAve) {
    this.airTempAve = airTempAve;
  }

  public float getAirTempMax() {
    return airTempMax;
  }

  public void setAirTempMax(float airTempMax) {
    this.airTempMax = airTempMax;
  }

  public float getAirTempMin() {
    return airTempMin;
  }

  public void setAirTempMin(float airTempMin) {
    this.airTempMin = airTempMin;
  }

  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  public float getDewPointAve() {
    return dewPointAve;
  }

  public void setDewPointAve(float dewPointAve) {
    this.dewPointAve = dewPointAve;
  }

  public float getDewPointMax() {
    return dewPointMax;
  }

  public void setDewPointMax(float dewPointMax) {
    this.dewPointMax = dewPointMax;
  }

  public float getDewPointMin() {
    return dewPointMin;
  }

  public void setDewPointMin(float dewPointMin) {
    this.dewPointMin = dewPointMin;
  }

  public float getHumidAve() {
    return humidAve;
  }

  public void setHumidAve(float humidAve) {
    this.humidAve = humidAve;
  }

  public float getHumidMax() {
    return humidMax;
  }

  public void setHumidMax(float humidMax) {
    this.humidMax = humidMax;
  }

  public float getHumidMin() {
    return humidMin;
  }

  public void setHumidMin(float humidMin) {
    this.humidMin = humidMin;
  }

  public float getSoilTempAAve() {
    return soilTempAAve;
  }

  public void setSoilTempAAve(float soilTempAAve) {
    this.soilTempAAve = soilTempAAve;
  }

  public float getSoilTempAMax() {
    return soilTempAMax;
  }

  public void setSoilTempAMax(float soilTempAMax) {
    this.soilTempAMax = soilTempAMax;
  }

  public float getSoilTempAMin() {
    return soilTempAMin;
  }

  public void setSoilTempAMin(float soilTempAMin) {
    this.soilTempAMin = soilTempAMin;
  }

  public float getSoilTempBAve() {
    return soilTempBAve;
  }

  public void setSoilTempBAve(float soilTempBAve) {
    this.soilTempBAve = soilTempBAve;
  }

  public float getSoilTempBMax() {
    return soilTempBMax;
  }

  public void setSoilTempBMax(float soilTempBMax) {
    this.soilTempBMax = soilTempBMax;
  }

  public float getSoilTempBMin() {
    return soilTempBMin;
  }

  public void setSoilTempBMin(float soilTempBMin) {
    this.soilTempBMin = soilTempBMin;
  }

  @Override
  public String toString() {
    return "DateSummary:" + date + " " + airTempMax + "," + airTempAve + "," + airTempMin + "...";
  }

  public int compareTo(Object o) {
    DateSummary comparator = (DateSummary) o;
    String compDate = comparator.getDate();
    int compYear = Integer.parseInt(compDate.substring(6));
    int thisYear = Integer.parseInt(this.date.substring(6));
    if (compYear > thisYear) {
      return -1;
    } else if(compYear < thisYear) {
      return 1;
    } else {
      int compMonth = Integer.parseInt(compDate.substring(0, 2));
      int thisMonth = Integer.parseInt(this.date.substring(0, 2));
      if (compMonth > thisMonth) {
        return -1;
      } else if(compMonth < thisMonth) {
        return 1;
      } else {
        int compDay = Integer.parseInt(compDate.substring(3, 5));
        int thisDay = Integer.parseInt(this.date.substring(3, 5));
        if (compDay > thisDay) {
          return -1;
        } else {
          return 1;
        }
      }
    }
  }
}
