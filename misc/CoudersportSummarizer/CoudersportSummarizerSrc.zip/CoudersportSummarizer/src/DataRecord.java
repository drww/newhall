public class DataRecord {

  String date;
  float soilTempA;
  float soilTempB;
  float humidity;
  float airTemp;
  float dewPoint;

  public DataRecord(String date, float soilTempA, float soilTempB, float humidity, float airTemp, float dewPoint) {
    this.date = date;
    this.soilTempA = soilTempA;
    this.soilTempB = soilTempB;
    this.humidity = humidity;
    this.airTemp = airTemp;
    this.dewPoint = dewPoint;
  }

  public DataRecord() {
    // Empty constructor.
  }

  public float getAirTemp() {
    return airTemp;
  }

  public void setAirTemp(float airTemp) {
    this.airTemp = airTemp;
  }

  public String getDate() {
    return date;
  }

  public void setDate(String date) {
    this.date = date;
  }

  public float getDewPoint() {
    return dewPoint;
  }

  public void setDewPoint(float dewPoint) {
    this.dewPoint = dewPoint;
  }

  public float getHumidity() {
    return humidity;
  }

  public void setHumidity(float humidity) {
    this.humidity = humidity;
  }

  public float getSoilTempA() {
    return soilTempA;
  }

  public void setSoilTempA(float soilTempA) {
    this.soilTempA = soilTempA;
  }

  public float getSoilTempB() {
    return soilTempB;
  }

  public void setSoilTempB(float soilTempB) {
    this.soilTempB = soilTempB;
  }

  @Override
  public String toString() {
    return date + "," + soilTempA + "," + soilTempB + "," + 
            humidity + "," + airTemp + "," + dewPoint;
  }

}
