
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.LinkedList;
import java.util.TreeSet;

public class Summarizer {

  public static void main(String[] args) {

    if (args.length != 2) {
      System.out.println("Please specify both an input and output file.");
      System.out.println("Usage: java -jar CoudersportSummarizer.jar inputFile outputFile");
      System.exit(-1);
    }

    BufferedReader infile = null;
    BufferedWriter outfile = null;

    try {
      FileReader fis = new FileReader(args[0]);
      FileWriter fos = new FileWriter(args[1]);
      infile = new BufferedReader(fis);
      outfile = new BufferedWriter(fos);
    } catch (Exception e) {
      System.out.println("Could not open files, wrong path or insufficient privs.");
      System.exit(-1);
    }

    LinkedList<DataRecord> records = new LinkedList<DataRecord>();
    int droppedRows = 0;

    try {
      System.out.println("Column Headers: " + infile.readLine());
      String line = null;

      while ((line = infile.readLine()) != null) {

        boolean shouldAdd = true;

        String fields[] = line.split(",");
        String dateFields[] = fields[0].split("/");
        int monthInt = Integer.parseInt(dateFields[0]);
        String month;
        if (monthInt < 10) {
          month = "0" + monthInt;
        } else {
          month = String.valueOf(monthInt);
        }
        int dayInt = Integer.parseInt(dateFields[1]);
        String day;
        if (dayInt < 10) {
          day = "0" + dayInt;
        } else {
          day = String.valueOf(dayInt);
        }
        int year = Integer.parseInt(dateFields[2].substring(0, 4));

        for (int i = 1; i <= 5; i++) {
          if (fields[i].equals("\"*\"") || fields[i].isEmpty()) {
            fields[i] = "-999";
            shouldAdd = false;
          }
        }

        // "Date & Time","ST @ 2 in","ST@ 20 in","% HMD","AT","DP Temp"

        DataRecord newRecord = new DataRecord();
        newRecord.setDate(month + "/" + day + "/" + year);
        newRecord.setSoilTempA(Float.parseFloat(fields[1]));
        newRecord.setSoilTempB(Float.parseFloat(fields[2]));
        newRecord.setHumidity(Float.parseFloat(fields[3]));
        newRecord.setAirTemp(Float.parseFloat(fields[4]));
        newRecord.setDewPoint(Float.parseFloat(fields[5]));

        if (shouldAdd) {
          records.add(newRecord);
        } else {
          droppedRows++;
        }

      }

    } catch (Exception e) {
      System.out.println("File reading error, exiting.");
      System.exit(-1);
    }

    System.out.println("File read, dropped rows: " + droppedRows);
    System.out.println("Records span " + records.size() + " unique rows.");

    // Begin analysis.

    TreeSet<String> uniqueDates = new TreeSet<String>();
    for (DataRecord record : records) {
      uniqueDates.add(record.getDate());
    }

    System.out.println("Records span " + uniqueDates.size() + " days.");

    TreeSet<DateSummary> results = new TreeSet<DateSummary>();

    for (String uniqueDate : uniqueDates) {

      LinkedList<DataRecord> recordsForDate = new LinkedList<DataRecord>();
      for (DataRecord record : records) {
        if (record.getDate().equals(uniqueDate)) {
          recordsForDate.add(record);
        }
      }

      LinkedList<Float> soilTempA = new LinkedList<Float>();
      LinkedList<Float> soilTempB = new LinkedList<Float>();
      LinkedList<Float> humidity = new LinkedList<Float>();
      LinkedList<Float> airTemp = new LinkedList<Float>();
      LinkedList<Float> dewPoint = new LinkedList<Float>();

      for (DataRecord record : recordsForDate) {
        soilTempA.add(record.getSoilTempA());
        soilTempB.add(record.getSoilTempB());
        humidity.add(record.getHumidity());
        airTemp.add(record.getAirTemp());
        dewPoint.add(record.getDewPoint());
      }

      DateSummary result = new DateSummary(uniqueDate, soilTempA,
              soilTempB, humidity, airTemp, dewPoint);
      results.add(result);

    }

    // Summation:(Tmax + tmin)/2 – (40 or 50) "heat units"

    double thermalUnit50Air = 0.0;
    double thermalUnit40Air = 0.0;
    double thermalUnit50SoilA = 0.0;
    double thermalUnit40SoilA = 0.0;
    double thermalUnit50SoilB = 0.0;
    double thermalUnit40SoilB = 0.0;

    for (DateSummary result : results) {
      thermalUnit50Air += (result.getAirTempMax() + result.getAirTempMin())/2 - 50;
      thermalUnit40Air += (result.getAirTempMax() + result.getAirTempMin())/2 - 40;
      thermalUnit50SoilA += (result.getSoilTempAMax() + result.getSoilTempAMin())/2 - 50;
      thermalUnit40SoilA += (result.getSoilTempAMax() + result.getSoilTempAMin())/2 - 40;
      thermalUnit50SoilB += (result.getSoilTempBMax() + result.getSoilTempBMin())/2 - 50;
      thermalUnit40SoilB += (result.getSoilTempBMax() + result.getSoilTempBMin())/2 - 40;
    }

    System.out.println("Heat Units (Air): " + thermalUnit50Air + " (base 50), "
            + thermalUnit40Air + " (base 40)");
    System.out.println("Heat Units (SoilA): " + thermalUnit50SoilA + " (base 50), "
            + thermalUnit40SoilA + " (base 40)");
    System.out.println("Heat Units (SoilB): " + thermalUnit50SoilB + " (base 50), "
            + thermalUnit40SoilB + " (base 40)");
    System.out.println("Writing result to file, total records: " + results.size());

    try {
      String part1 = "DATE,SOIL_A_MAX,SOIL_A_AVE,SOIL_A_MIN,";
      String part2 = "SOIL_B_MAX,SOIL_B_AVE,SOIL_B_MIN,";
      String part3 = "HUMID_MAX,HUMID_AVE,HUMID_MIN,";
      String part4 = "AIR_TEMP_MAX,AIR_TEMP_AVE,AIR_TEMP_MIN,";
      String part5 = "DEW_POINT_MAX,DEW_POINT_AVE,DEW_POINT_MIN";

      outfile.write(part1 + part2 + part3 + part4 + part5 + "\n");

      for (DateSummary result : results) {
        outfile.write(result.getDate() + ",");
        outfile.write(result.getSoilTempAMax() + ",");
        outfile.write(result.getSoilTempAAve() + ",");
        outfile.write(result.getSoilTempAMin() + ",");
        outfile.write(result.getSoilTempBMax() + ",");
        outfile.write(result.getSoilTempBAve() + ",");
        outfile.write(result.getSoilTempBMin() + ",");
        outfile.write(result.getHumidMax() + ",");
        outfile.write(result.getHumidAve() + ",");
        outfile.write(result.getHumidMin() + ",");
        outfile.write(result.getAirTempMax() + ",");
        outfile.write(result.getAirTempAve() + ",");
        outfile.write(result.getAirTempMin() + ",");
        outfile.write(result.getDewPointMax() + ",");
        outfile.write(result.getDewPointAve() + ",");
        outfile.write(result.getDewPointMin() + ",");
        outfile.write('\n');
        outfile.flush();
      }
    } catch (Exception e) {
      System.out.println("Error writing to file.");
      System.exit(-1);
    }

    System.out.println("Wrote daily statistics to file, done.");

  }
}
